﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.Resource
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace TDGWVDSync_Client
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resource
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resource()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (Resource.resourceMan == null)
          Resource.resourceMan = new ResourceManager("TDGWVDSync_Client.Resource", typeof (Resource).Assembly);
        return Resource.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => Resource.resourceCulture;
      set => Resource.resourceCulture = value;
    }

    internal static Bitmap IMG_COMP_LOGIN_LOGO_A_techdataglobal => (Bitmap) Resource.ResourceManager.GetObject(nameof (IMG_COMP_LOGIN_LOGO_A_techdataglobal), Resource.resourceCulture);
  }
}
