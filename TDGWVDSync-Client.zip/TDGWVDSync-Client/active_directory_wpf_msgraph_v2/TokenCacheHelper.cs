﻿// Decompiled with JetBrains decompiler
// Type: active_directory_wpf_msgraph_v2.TokenCacheHelper
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using Microsoft.Identity.Client;
using System;
using System.IO;
using System.Security.Cryptography;

namespace active_directory_wpf_msgraph_v2
{
  internal static class TokenCacheHelper
  {
    public static readonly string CacheFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TDGWVDSync", "cache.msalcache.bin3");
    private static readonly object FileLock = new object();

    public static void BeforeAccessNotification(TokenCacheNotificationArgs args)
    {
      lock (TokenCacheHelper.FileLock)
      {
        string directoryName = Path.GetDirectoryName(TokenCacheHelper.CacheFilePath);
        if (!Directory.Exists(directoryName))
          Directory.CreateDirectory(directoryName);
        args.TokenCache.DeserializeMsalV3(File.Exists(TokenCacheHelper.CacheFilePath) ? ProtectedData.Unprotect(File.ReadAllBytes(TokenCacheHelper.CacheFilePath), (byte[]) null, DataProtectionScope.CurrentUser) : (byte[]) null);
      }
    }

    public static void AfterAccessNotification(TokenCacheNotificationArgs args)
    {
      if (!args.HasStateChanged)
        return;
      lock (TokenCacheHelper.FileLock)
      {
        string directoryName = Path.GetDirectoryName(TokenCacheHelper.CacheFilePath);
        if (!Directory.Exists(directoryName))
          Directory.CreateDirectory(directoryName);
        File.WriteAllBytes(TokenCacheHelper.CacheFilePath, ProtectedData.Protect(args.TokenCache.SerializeMsalV3(), (byte[]) null, DataProtectionScope.CurrentUser));
      }
    }

    internal static void EnableSerialization(ITokenCache tokenCache)
    {
      tokenCache.SetBeforeAccess(new TokenCacheCallback(TokenCacheHelper.BeforeAccessNotification));
      tokenCache.SetAfterAccess(new TokenCacheCallback(TokenCacheHelper.AfterAccessNotification));
    }
  }
}
