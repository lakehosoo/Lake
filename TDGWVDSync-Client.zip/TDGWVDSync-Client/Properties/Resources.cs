﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.Properties.Resources
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace TDGWVDSync_Client.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (TDGWVDSync_Client.Properties.Resources.resourceMan == null)
          TDGWVDSync_Client.Properties.Resources.resourceMan = new ResourceManager("TDGWVDSync_Client.Properties.Resources", typeof (TDGWVDSync_Client.Properties.Resources).Assembly);
        return TDGWVDSync_Client.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => TDGWVDSync_Client.Properties.Resources.resourceCulture;
      set => TDGWVDSync_Client.Properties.Resources.resourceCulture = value;
    }

    internal static Bitmap IMG_COMP_LOGIN_LOGO_A_techdataglobal => (Bitmap) TDGWVDSync_Client.Properties.Resources.ResourceManager.GetObject(nameof (IMG_COMP_LOGIN_LOGO_A_techdataglobal), TDGWVDSync_Client.Properties.Resources.resourceCulture);
  }
}
