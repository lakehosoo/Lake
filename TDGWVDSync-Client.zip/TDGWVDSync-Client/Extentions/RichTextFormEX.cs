﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.Extentions.RichTextFormEX
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using System;
using System.Drawing;
using System.Windows.Forms;

namespace TDGWVDSync_Client.Extentions
{
  public static class RichTextFormEX
  {
    public static void AppendTextLine(this RichTextBox richTextBox, string text)
    {
      if (richTextBox.Text.Length > 0)
        text = Environment.NewLine + text;
      richTextBox.AppendText(text);
    }

    public static void AppendTextLine(this RichTextBox richTextBox, string text, Color textColor)
    {
      if (richTextBox.Text.Length > 0)
        text = Environment.NewLine + text;
      richTextBox.SelectionStart = richTextBox.TextLength;
      richTextBox.SelectionColor = Color.Green;
      richTextBox.SelectionStart = richTextBox.TextLength;
      richTextBox.SelectionColor = textColor;
      richTextBox.AppendText(text);
      richTextBox.SelectionStart = richTextBox.TextLength;
      richTextBox.SelectionColor = SystemColors.WindowText;
    }

    public static void AppendTextLine(
      this RichTextBox richTextBox,
      string text,
      Color textColor,
      Font font)
    {
      if (richTextBox.Text.Length > 0)
        text = Environment.NewLine + text;
      richTextBox.SelectionStart = richTextBox.TextLength;
      richTextBox.SelectionColor = Color.Green;
      richTextBox.SelectionStart = richTextBox.TextLength;
      richTextBox.SelectionColor = textColor;
      richTextBox.SelectionFont = font;
      richTextBox.AppendText(text);
      richTextBox.SelectionStart = richTextBox.TextLength;
      richTextBox.SelectionColor = SystemColors.WindowText;
    }

    public static void AppendTextLine(
      this RichTextBox richTextBox,
      string text,
      Color textColot,
      int bulletIndent)
    {
      if (richTextBox.Text.Length > 0)
        text = Environment.NewLine + text;
      richTextBox.SelectionBullet = true;
      richTextBox.SelectionStart = richTextBox.TextLength;
      richTextBox.SelectionColor = Color.Green;
      richTextBox.SelectionStart = richTextBox.TextLength;
      richTextBox.SelectionColor = textColot;
      richTextBox.AppendText(text);
      richTextBox.BulletIndent = bulletIndent;
      richTextBox.SelectionBullet = false;
      richTextBox.SelectionStart = richTextBox.TextLength;
      richTextBox.SelectionColor = SystemColors.WindowText;
    }
  }
}
