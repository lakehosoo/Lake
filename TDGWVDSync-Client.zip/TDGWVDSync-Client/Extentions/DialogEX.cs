﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.Extentions.DialogEX
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using System.Threading.Tasks;
using System.Windows.Forms;

namespace TDGWVDSync_Client.Extentions
{
  public static class DialogEX
  {
    public static async Task<DialogResult> ShowDialogAsync(this Form @this)
    {
      await Task.Yield();
      return !@this.IsDisposed ? @this.ShowDialog() : DialogResult.OK;
    }
  }
}
