﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.Core.AppManager
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using active_directory_wpf_msgraph_v2;
using Microsoft.Identity.Client;
using Newtonsoft.Json;
using StringCipher;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using TDGWVDSync_Client.Extentions;

namespace TDGWVDSync_Client.Core
{
  public static class AppManager
  {
    public static RichTextBox output;
    private static readonly string APP_SETTING_PATH = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "TDGWVDSync", "AppSetting");
    public const string API_URI_GRAPH_ME = "https://graph.microsoft.com/v1.0/me";
    public const string API_PATH_VMLIST = "/api/GetVMList";
    public const string API_PATH_POWER = "/api/power";
    public const string API_PATH_STATUS = "/api/status";
    private static IPublicClientApplication clientApp;
    private static string accessToken;
    public static AppManager.Profile profile;

    public static AppManager.AppSetting appSetting
    {
      get
      {
        if (!File.Exists(AppManager.APP_SETTING_PATH))
        {
          string directoryName = Path.GetDirectoryName(AppManager.APP_SETTING_PATH);
          if (!Directory.Exists(directoryName))
            Directory.CreateDirectory(directoryName);
          File.WriteAllText(AppManager.APP_SETTING_PATH, JsonConvert.SerializeObject((object) new AppManager.AppSetting()));
        }
        return JsonConvert.DeserializeObject<AppManager.AppSetting>(StringCipher128.Decrypt(File.ReadAllText(AppManager.APP_SETTING_PATH), "tdg3000djr!"));
      }
      set
      {
        string contents = JsonConvert.SerializeObject((object) value);
        File.WriteAllText(AppManager.APP_SETTING_PATH, contents);
      }
    }

    public static async Task<string> GetAccessTokenWithLogin(string uri = "https://graph.microsoft.com/v1.0/me")
    {
      string accessTokenWithLogin = await AppManager.GetAccessTokenWithLogin(uri, AppManager.appSetting.clientId, AppManager.appSetting.tenantId);
      return accessTokenWithLogin;
    }

    public static async Task<string> GetAccessTokenWithLogin(
      string uri,
      string clientId,
      string tenentId)
    {
      if (uri.StartsWith("http://localhost"))
        return AppManager.accessToken = string.Empty;
      AppManager.clientApp = PublicClientApplicationBuilder.Create(clientId).WithDefaultRedirectUri().WithAuthority("https://login.microsoftonline.com/" + tenentId).Build();
      TokenCacheHelper.EnableSerialization(AppManager.clientApp.UserTokenCache);
      IEnumerable<IAccount> accounts = await AppManager.clientApp.GetAccountsAsync();
      IAccount account = accounts.FirstOrDefault<IAccount>();
      string[] scopes = (string[]) null;
      if (uri.StartsWith("https://graph.microsoft.com"))
        scopes = new string[1]
        {
          "https://graph.microsoft.com/User.Read"
        };
      else if (uri.StartsWith(AppManager.appSetting.baseUri))
        scopes = new string[1]
        {
          AppManager.appSetting.baseUri + "/user_impersonation"
        };
      AuthenticationResult authResult;
      try
      {
        try
        {
          try
          {
            authResult = await AppManager.clientApp.AcquireTokenSilent((IEnumerable<string>) scopes, account).ExecuteAsync();
          }
          catch (MsalUiRequiredException ex)
          {
            authResult = await AppManager.clientApp.AcquireTokenInteractive((IEnumerable<string>) scopes).ExecuteAsync();
          }
        }
        catch (MsalClientException ex)
        {
          return string.Empty;
        }
      }
      catch (Exception ex)
      {
        AppManager.output.AppendTextLine(ex.ToString());
        return string.Empty;
      }
      return AppManager.accessToken = authResult.AccessToken;
    }

    public static async Task Logout()
    {
      IEnumerable<IAccount> accounts = await AppManager.clientApp.GetAccountsAsync();
      if (!accounts.Any<IAccount>())
      {
        accounts = (IEnumerable<IAccount>) null;
      }
      else
      {
        try
        {
          await AppManager.clientApp.RemoveAsync(accounts.FirstOrDefault<IAccount>());
          AppManager.accessToken = (string) null;
        }
        catch (MsalException ex)
        {
        }
        accounts = (IEnumerable<IAccount>) null;
      }
    }

    public static async Task<string> RequestAPI(
      HttpMethod method,
      string apiUri,
      Dictionary<string, string> param = null)
    {
      Uri uri = new Uri(new Uri(AppManager.appSetting.baseUri), apiUri);
      string str = await AppManager.Request(method, uri.AbsoluteUri, param);
      uri = (Uri) null;
      return str;
    }

    public static async Task<string> Request(
      HttpMethod method,
      string uri,
      Dictionary<string, string> param = null)
    {
      string result = string.Empty;
      string str1 = await AppManager.GetAccessTokenWithLogin(uri);
      AppManager.accessToken = str1;
      str1 = (string) null;
      try
      {
        using (HttpClient client = new HttpClient())
        {
          client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", AppManager.accessToken);
          if (method == HttpMethod.Post)
          {
            if (param != null)
            {
              FormUrlEncodedContent content = new FormUrlEncodedContent((IEnumerable<KeyValuePair<string, string>>) param);
              HttpResponseMessage response = await client.PostAsync(uri, (HttpContent) content);
              string str2 = await response.Content.ReadAsStringAsync();
              return str2;
            }
            HttpResponseMessage response1 = await client.PostAsync(uri, (HttpContent) null);
            string str3 = await response1.Content.ReadAsStringAsync();
            return str3;
          }
          if (param != null && param.Count > 0)
            uri = uri + "?" + string.Join("&", param.Select<KeyValuePair<string, string>, string>((Func<KeyValuePair<string, string>, string>) (kvp => kvp.Key + "=" + HttpUtility.UrlEncode(kvp.Value))));
          HttpResponseMessage respone = await client.GetAsync(uri);
          result = await respone.Content.ReadAsStringAsync();
          respone = (HttpResponseMessage) null;
        }
      }
      catch (TaskCanceledException ex)
      {
        await Task.Delay(3000);
        result = await AppManager.Request(method, uri, param);
      }
      return result;
    }

    public struct Profile
    {
      public string userPrincipalName;
    }

    public struct AppSetting
    {
      public string tenantId;
      public string clientId;
      public string baseUri;
    }
  }
}
