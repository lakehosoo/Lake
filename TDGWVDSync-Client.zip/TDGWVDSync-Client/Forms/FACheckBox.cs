﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.Forms.FACheckBox
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using FontAwesome.Sharp;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace TDGWVDSync_Client.Forms
{
  public class FACheckBox : UserControl
  {
    private bool _value = false;
    private IContainer components = (IContainer) null;
    private IconPictureBox iconPictureBox1;

    public bool Value
    {
      get => this._value;
      set
      {
        this._value = value;
        this.iconPictureBox1.IconChar = value ? IconChar.CheckSquare : IconChar.Square;
      }
    }

    public FACheckBox()
    {
      this.InitializeComponent();
      this.iconPictureBox1.IconColor = this.ForeColor;
    }

    protected override void OnForeColorChanged(EventArgs e)
    {
      base.OnForeColorChanged(e);
      this.iconPictureBox1.IconColor = this.ForeColor;
    }

    private void iconPictureBox1_Up(object sender, EventArgs e)
    {
      this.Value = !this.Value;
      this.OnClick(e);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.iconPictureBox1 = new IconPictureBox();
      ((ISupportInitialize) this.iconPictureBox1).BeginInit();
      this.SuspendLayout();
      this.iconPictureBox1.BackColor = Color.Transparent;
      this.iconPictureBox1.Dock = DockStyle.Fill;
      this.iconPictureBox1.IconChar = IconChar.Square;
      this.iconPictureBox1.IconColor = Color.White;
      this.iconPictureBox1.IconSize = 26;
      this.iconPictureBox1.Location = new Point(0, 0);
      this.iconPictureBox1.Name = "iconPictureBox1";
      this.iconPictureBox1.Size = new Size(28, 26);
      this.iconPictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
      this.iconPictureBox1.TabIndex = 0;
      this.iconPictureBox1.TabStop = false;
      this.iconPictureBox1.Click += new EventHandler(this.iconPictureBox1_Up);
      this.iconPictureBox1.DoubleClick += new EventHandler(this.iconPictureBox1_Up);
      this.AutoScaleDimensions = new SizeF(7f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.Transparent;
      this.Controls.Add((Control) this.iconPictureBox1);
      this.Name = nameof (FACheckBox);
      this.Size = new Size(28, 26);
      ((ISupportInitialize) this.iconPictureBox1).EndInit();
      this.ResumeLayout(false);
    }
  }
}
