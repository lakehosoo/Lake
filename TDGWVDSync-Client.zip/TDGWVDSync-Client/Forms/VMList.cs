﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.Forms.VMList
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace TDGWVDSync_Client.Forms
{
  public class VMList : UserControl
  {
    public static List<VMList> All = new List<VMList>();
    public static List<VMList> Checked = new List<VMList>();
    public static Action<VMList> OnChangeCheckedList = (Action<VMList>) null;
    private string _labelText;
    private bool _isLoading;
    private int _frameCount = 0;
    private IContainer components = (IContainer) null;
    private Panel panel1;
    private Timer updateTimer;
    private Panel panel2;
    private FACheckBox check;
    private Panel panel3;
    private Label text;
    private Label lbVMName;

    public string VMName
    {
      get => this.lbVMName.Text;
      set => this.lbVMName.Text = value;
    }

    public bool Value
    {
      get => this.check.Value;
      set
      {
        this.check.Value = value;
        if (this.check.Value)
        {
          if (!VMList.Checked.Contains(this))
            VMList.Checked.Add(this);
        }
        else
          VMList.Checked.Remove(this);
        Action<VMList> changeCheckedList = VMList.OnChangeCheckedList;
        if (changeCheckedList == null)
          return;
        changeCheckedList(this);
      }
    }

    public string LabelText
    {
      get => this._labelText;
      set
      {
        this.text.Text = value;
        this._labelText = value;
      }
    }

    public bool IsOn { get; set; }

    public static void Clear()
    {
      VMList.All.Clear();
      VMList.Checked.Clear();
    }

    public VMList()
    {
      this.InitializeComponent();
      this.updateTimer.Tick += new EventHandler(this.UpdateTimer);
      this.updateTimer.Interval = 300;
      this.updateTimer.Start();
      this.PowerOn(false);
      VMList.All.Add(this);
    }

    public void Release()
    {
      VMList.All.Remove(this);
      VMList.Checked.Remove(this);
    }

    private void UpdateTimer(object sender, EventArgs e)
    {
      if (!this._isLoading)
        return;
      this.text.Text = this._labelText;
      for (int index = 0; index < this._frameCount; ++index)
        this.text.Text += ".";
      ++this._frameCount;
      this._frameCount %= 4;
    }

    public void Loading(bool enable)
    {
      this._isLoading = enable;
      if (!this._isLoading)
        this.text.Text = this._labelText;
      else
        this.BackColor = Color.FromArgb(42, 42, 44);
    }

    public void PowerOn(bool isOn)
    {
      this.BackColor = isOn ? Color.FromArgb(0, 89, 9) : Color.FromArgb(0, 0, 0);
      this.LabelText = isOn ? "원격 접속 가능" : "VM 전원 꺼짐";
      this.lbVMName.ForeColor = this.text.ForeColor = Color.White;
      this.IsOn = isOn;
    }

    private void label1_Click(object sender, EventArgs e)
    {
    }

    private void OnVMListClick(object sender, EventArgs e) => this.Value = !this.Value;

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      this.panel1 = new Panel();
      this.panel2 = new Panel();
      this.check = new FACheckBox();
      this.panel3 = new Panel();
      this.updateTimer = new Timer(this.components);
      this.lbVMName = new Label();
      this.text = new Label();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      this.panel1.BackColor = Color.Transparent;
      this.panel1.BackgroundImageLayout = ImageLayout.None;
      this.panel1.Controls.Add((Control) this.panel2);
      this.panel1.Controls.Add((Control) this.text);
      this.panel1.Controls.Add((Control) this.lbVMName);
      this.panel1.Controls.Add((Control) this.check);
      this.panel1.Controls.Add((Control) this.panel3);
      this.panel1.Dock = DockStyle.Fill;
      this.panel1.Location = new Point(0, 0);
      this.panel1.Name = "panel1";
      this.panel1.Size = new Size(505, 30);
      this.panel1.TabIndex = 3;
      this.panel1.Click += new EventHandler(this.OnVMListClick);
      this.panel1.DoubleClick += new EventHandler(this.OnVMListClick);
      this.panel2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
      this.panel2.BorderStyle = BorderStyle.FixedSingle;
      this.panel2.Location = new Point(10, 28);
      this.panel2.Name = "panel2";
      this.panel2.Size = new Size(487, 1);
      this.panel2.TabIndex = 0;
      this.check.BackColor = Color.Transparent;
      this.check.Dock = DockStyle.Left;
      this.check.Enabled = false;
      this.check.ForeColor = Color.White;
      this.check.Location = new Point(10, 0);
      this.check.Name = "check";
      this.check.Size = new Size(33, 30);
      this.check.TabIndex = 15;
      this.check.Value = false;
      this.panel3.BackColor = Color.Transparent;
      this.panel3.Dock = DockStyle.Left;
      this.panel3.Location = new Point(0, 0);
      this.panel3.Name = "panel3";
      this.panel3.Size = new Size(10, 30);
      this.panel3.TabIndex = 10;
      this.lbVMName.BackColor = Color.Transparent;
      this.lbVMName.Dock = DockStyle.Left;
      this.lbVMName.Font = new Font("굴림", 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 129);
      this.lbVMName.ForeColor = Color.White;
      this.lbVMName.Location = new Point(43, 0);
      this.lbVMName.Name = "lbVMName";
      this.lbVMName.Size = new Size(187, 30);
      this.lbVMName.TabIndex = 19;
      this.lbVMName.Text = "label1123146";
      this.lbVMName.TextAlign = ContentAlignment.MiddleLeft;
      this.text.BackColor = Color.Transparent;
      this.text.Dock = DockStyle.Fill;
      this.text.Font = new Font("굴림", 12f, FontStyle.Regular, GraphicsUnit.Point, (byte) 129);
      this.text.ForeColor = Color.White;
      this.text.Location = new Point(230, 0);
      this.text.Name = "text";
      this.text.Padding = new Padding(0, 0, 10, 0);
      this.text.Size = new Size(275, 30);
      this.text.TabIndex = 20;
      this.text.Text = "label1123146";
      this.text.TextAlign = ContentAlignment.MiddleRight;
      this.AutoScaleDimensions = new SizeF(7f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.FromArgb(89, 0, 0);
      this.Controls.Add((Control) this.panel1);
      this.Name = nameof (VMList);
      this.Size = new Size(505, 30);
      this.panel1.ResumeLayout(false);
      this.ResumeLayout(false);
    }
  }
}
