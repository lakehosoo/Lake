﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.Forms.SettingForm
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using TDGWVDSync_Client.Core;

namespace TDGWVDSync_Client.Forms
{
  public class SettingForm : Form
  {
    private IContainer components = (IContainer) null;
    private Label label2;
    private TextBox txtClientId;
    private Label label3;
    private TextBox txtTenantId;
    private Button Apply;
    private Label label4;
    private TextBox txtBaseURI;

    public SettingForm()
    {
      this.InitializeComponent();
      this.FormBorderStyle = FormBorderStyle.FixedDialog;
    }

    protected override void OnShown(EventArgs e)
    {
      base.OnShown(e);
      AppManager.AppSetting appSetting = AppManager.appSetting;
      this.txtTenantId.Text = appSetting.tenantId;
      this.txtClientId.Text = appSetting.clientId;
      this.txtBaseURI.Text = appSetting.baseUri;
    }

    private void Apply_Click(object sender, EventArgs e)
    {
      if (string.IsNullOrEmpty(this.txtTenantId.Text) || string.IsNullOrEmpty(this.txtClientId.Text) || string.IsNullOrEmpty(this.txtBaseURI.Text))
      {
        int num = (int) MessageBox.Show("빈값의 데이터가 있으면 안됩니다.\n(Id/값을 분실 하였을 경우 관리자에게 문의해주세요)");
      }
      else
      {
        AppManager.AppSetting appSetting1 = AppManager.appSetting;
        AppManager.AppSetting appSetting2 = new AppManager.AppSetting()
        {
          tenantId = this.txtTenantId.Text,
          clientId = this.txtClientId.Text,
          baseUri = this.txtBaseURI.Text
        };
        if (appSetting1.tenantId != appSetting2.tenantId || appSetting1.clientId != appSetting2.clientId || appSetting1.baseUri != appSetting2.baseUri)
        {
          if (!string.IsNullOrEmpty(appSetting2.tenantId))
          {
            if (MessageBox.Show("정보가 변경되어 로그아웃 됩니다.\n계속 진행하시겠습니까?", "설정", MessageBoxButtons.YesNo) != DialogResult.Yes)
              return;
            AppManager.appSetting = appSetting2;
            this.DialogResult = DialogResult.Yes;
          }
          else
            this.DialogResult = DialogResult.Yes;
        }
        else
          this.DialogResult = DialogResult.Cancel;
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label2 = new Label();
      this.txtClientId = new TextBox();
      this.label3 = new Label();
      this.txtTenantId = new TextBox();
      this.Apply = new Button();
      this.label4 = new Label();
      this.txtBaseURI = new TextBox();
      this.SuspendLayout();
      this.label2.AutoSize = true;
      this.label2.Font = new Font("굴림", 11.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 129);
      this.label2.Location = new Point(17, 45);
      this.label2.Name = "label2";
      this.label2.Size = new Size(112, 15);
      this.label2.TabIndex = 3;
      this.label2.Text = "Client Id(App Id)";
      this.label2.TextAlign = ContentAlignment.MiddleLeft;
      this.txtClientId.Location = new Point(144, 42);
      this.txtClientId.Name = "txtClientId";
      this.txtClientId.Size = new Size(358, 21);
      this.txtClientId.TabIndex = 2;
      this.label3.AutoSize = true;
      this.label3.Font = new Font("굴림", 11.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 129);
      this.label3.Location = new Point(17, 18);
      this.label3.Name = "label3";
      this.label3.Size = new Size(67, 15);
      this.label3.TabIndex = 5;
      this.label3.Text = "Tenant Id";
      this.label3.TextAlign = ContentAlignment.MiddleLeft;
      this.txtTenantId.Location = new Point(144, 15);
      this.txtTenantId.Name = "txtTenantId";
      this.txtTenantId.Size = new Size(358, 21);
      this.txtTenantId.TabIndex = 4;
      this.Apply.Location = new Point(427, 99);
      this.Apply.Name = "Apply";
      this.Apply.Size = new Size(75, 23);
      this.Apply.TabIndex = 6;
      this.Apply.Text = "OK";
      this.Apply.UseVisualStyleBackColor = true;
      this.Apply.Click += new EventHandler(this.Apply_Click);
      this.label4.AutoSize = true;
      this.label4.Font = new Font("굴림", 11.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 129);
      this.label4.Location = new Point(17, 72);
      this.label4.Name = "label4";
      this.label4.Size = new Size(96, 15);
      this.label4.TabIndex = 8;
      this.label4.Text = "API Base URI";
      this.label4.TextAlign = ContentAlignment.MiddleLeft;
      this.txtBaseURI.Location = new Point(144, 69);
      this.txtBaseURI.Name = "txtBaseURI";
      this.txtBaseURI.Size = new Size(358, 21);
      this.txtBaseURI.TabIndex = 7;
      this.AutoScaleDimensions = new SizeF(7f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
      this.ClientSize = new Size(524, 138);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.txtBaseURI);
      this.Controls.Add((Control) this.Apply);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.txtTenantId);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.txtClientId);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (SettingForm);
      this.StartPosition = FormStartPosition.CenterParent;
      this.Text = "설정";
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
