﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.Forms.LoadingForm
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using System.ComponentModel;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using TDGWVDSync_Client.Extentions;

namespace TDGWVDSync_Client.Forms
{
  public class LoadingForm : Form
  {
    private IContainer components = (IContainer) null;
    private ProgressBar progressBar1;
    private Label Label;

    public string labelText
    {
      get => this.Label.Text;
      set => this.Label.Text = value;
    }

    public LoadingForm()
    {
      this.InitializeComponent();
      this.FormBorderStyle = FormBorderStyle.FixedDialog;
    }

    public async Task ShowLoading(LoadingForm.OnDialogProcess process)
    {
      Task<DialogResult> task = this.ShowDialogAsync();
      LoadingForm.OnDialogProcess onDialogProcess = process;
      await (onDialogProcess != null ? onDialogProcess() : (Task) null);
      this.Close();
      int num = (int) await task;
      task = (Task<DialogResult>) null;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (LoadingForm));
      this.progressBar1 = new ProgressBar();
      this.Label = new Label();
      this.SuspendLayout();
      this.progressBar1.Location = new Point(12, 12);
      this.progressBar1.Maximum = 30;
      this.progressBar1.Name = "progressBar1";
      this.progressBar1.Size = new Size(275, 24);
      this.progressBar1.Style = ProgressBarStyle.Marquee;
      this.progressBar1.TabIndex = 0;
      this.Label.AutoSize = true;
      this.Label.Location = new Point(12, 43);
      this.Label.Name = "Label";
      this.Label.Size = new Size(38, 12);
      this.Label.TabIndex = 1;
      this.Label.Text = "label1";
      this.AutoScaleDimensions = new SizeF(7f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(299, 62);
      this.ControlBox = false;
      this.Controls.Add((Control) this.Label);
      this.Controls.Add((Control) this.progressBar1);
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (LoadingForm);
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = FormStartPosition.CenterParent;
      this.Text = "Form1";
      this.ResumeLayout(false);
      this.PerformLayout();
    }

    public delegate Task OnDialogProcess();
  }
}
