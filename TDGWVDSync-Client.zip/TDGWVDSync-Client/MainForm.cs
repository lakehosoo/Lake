﻿// Decompiled with JetBrains decompiler
// Type: TDGWVDSync_Client.MainForm
// Assembly: TDGWVDSync-Client, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0DBBEB1C-ACB0-42FD-88B3-2D5DD6D478ED
// Assembly location: C:\Program Files (x86)\GS칼텍스 WVD-ONOFF\TDGWVDSync-Client.exe

using FontAwesome.Sharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using TDGWVDSync_Client.Core;
using TDGWVDSync_Client.Extentions;
using TDGWVDSync_Client.Forms;

namespace TDGWVDSync_Client
{
  public class MainForm : Form
  {
    private const string APP_TITLE = "GS칼텍스 WVD-ONOFF";
    private MainForm.State _state = MainForm.State.NONE;
    private LoadingForm loadingForm = new LoadingForm();
    private SettingForm settingForm = new SettingForm();
    private const string PROVISIONING_STATE = "ProvisioningState";
    private const string POWER_STATE = "PowerState";
    private const string PROVISIONING_SUCESSED = "";
    private const string POWER_ON = "VM running";
    private const string POWER_OFF = "VM deallocated";
    private IContainer components = (IContainer) null;
    private Panel panel3;
    private Panel panel2;
    private RichTextBox outPutTextBox;
    private FlowLayoutPanel flowLayoutPanel2;
    private PictureBox pictureBox1;
    private Panel panelVMList;
    private IconButton btnStart;
    private IconButton btnStop;
    private IconButton btnRestart;
    private IconButton btnRefresh;
    private FACheckBox checkAll;
    private IconButton btnLogin;
    private IconButton btnSetting;
    private IconButton btnLogout;
    private TextBox txtVersion;

    public MainForm()
    {
      this.InitializeComponent();
      this.outPutTextBox.TextChanged += new EventHandler(this.OutPutTextBox_TextChanged);
      VMList.OnChangeCheckedList += new Action<VMList>(this.OnChangeCheckedList);
      AppManager.output = this.outPutTextBox;
      ServicePointManager.Expect100Continue = true;
      ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
    }

    protected override void OnShown(EventArgs e)
    {
      base.OnShown(e);
      this.SetState(MainForm.State.NONE);
      this.OnChangeCheckedList((VMList) null);
      this.Login_Click((object) null, (EventArgs) null);
    }

    private async Task<Tuple<bool, JObject>> RequestVMState(
      VMList vm,
      string vmName,
      Action<string> callback)
    {
      Dictionary<string, string> param = new Dictionary<string, string>()
      {
        {
          nameof (vmName),
          vmName
        }
      };
      string jsonText = await AppManager.RequestAPI(HttpMethod.Get, "/api/status", param);
      JObject jsonObj = JObject.Parse(jsonText);
      string stateText = string.Empty;
      string provisioningState;
      if (jsonObj["ProvisioningState"] != null)
      {
        provisioningState = jsonObj["ProvisioningState"].ToString();
        stateText += provisioningState;
      }
      string powerState;
      if (jsonObj["PowerState"] != null)
      {
        powerState = jsonObj["PowerState"].ToString();
        stateText = stateText + " " + powerState;
      }
      bool isOn = jsonObj["result"].ToObject<bool>();
      Action<string> action = callback;
      if (action != null)
        action(stateText);
      Tuple<bool, JObject> tuple = Tuple.Create<bool, JObject>(isOn, jsonObj);
      param = (Dictionary<string, string>) null;
      jsonText = (string) null;
      jsonObj = (JObject) null;
      stateText = (string) null;
      provisioningState = (string) null;
      powerState = (string) null;
      return tuple;
    }

    private async Task<bool> VMStateUpdate(VMList vm, string vmName, Action<string> callback)
    {
      vm.LabelText = "상태 확인중";
      vm.Loading(true);
      Tuple<bool, JObject> tuple = await this.RequestVMState(vm, vmName, callback);
      bool isOn = tuple.Item1;
      vm.Loading(false);
      vm.VMName = vmName;
      vm.PowerOn(isOn);
      bool flag = isOn;
      tuple = (Tuple<bool, JObject>) null;
      return flag;
    }

    private async void VMRestart(VMList vm)
    {
      vm.LabelText = "재시작 요청중";
      vm.Loading(true);
      Dictionary<string, string> param = new Dictionary<string, string>()
      {
        {
          "vmName",
          vm.VMName
        },
        {
          "action",
          "restart"
        }
      };
      RichTextBox richTextBox = this.outPutTextBox;
      string text = await AppManager.RequestAPI(HttpMethod.Post, "/api/power", param);
      richTextBox.AppendTextLine(text, Color.Green);
      richTextBox = (RichTextBox) null;
      text = (string) null;
      bool isOn = false;
      vm.LabelText = "재시작중";
      vm.Loading(true);
      await Task.Delay(30000);
      do
      {
        Tuple<bool, JObject> tuple = await this.RequestVMState(vm, vm.VMName, (Action<string>) (stateText => vm.LabelText = "재시작중(" + stateText + ")"));
        isOn = tuple.Item1;
        JObject jsonObj = tuple.Item2;
        if (jsonObj["PowerState"] != null)
        {
          string power = jsonObj["PowerState"].ToString();
          if (!power.Equals("VM running") && !power.Equals("VM deallocated"))
            power = (string) null;
          else
            break;
        }
        if (!isOn)
          await Task.Delay(10000);
        tuple = (Tuple<bool, JObject>) null;
        jsonObj = (JObject) null;
      }
      while (!isOn);
      await Task.Delay(30000);
      vm.Loading(false);
      vm.PowerOn(isOn);
      Process.Start("ms-rd:");
      param = (Dictionary<string, string>) null;
    }

    private async void VMPowerOn(VMList vm, bool isOn)
    {
      if (!isOn)
      {
        Dictionary<string, string> param = new Dictionary<string, string>()
        {
          {
            "vmName",
            vm.VMName
          },
          {
            "action",
            "off"
          }
        };
        vm.LabelText = "전원 Off 요청중";
        vm.Loading(true);
        RichTextBox richTextBox = this.outPutTextBox;
        string text = await AppManager.RequestAPI(HttpMethod.Post, "/api/power", param);
        richTextBox.AppendTextLine(text, Color.Red);
        richTextBox = (RichTextBox) null;
        text = (string) null;
        vm.LabelText = "전원 Off 중";
        await Task.Delay(30000);
        vm.Loading(false);
        vm.PowerOn(false);
        param = (Dictionary<string, string>) null;
      }
      else
      {
        vm.LabelText = "부팅 요청중";
        vm.Loading(true);
        Dictionary<string, string> param = new Dictionary<string, string>()
        {
          {
            "vmName",
            vm.VMName
          },
          {
            "action",
            "on"
          }
        };
        RichTextBox richTextBox = this.outPutTextBox;
        string text = await AppManager.RequestAPI(HttpMethod.Post, "/api/power", param);
        richTextBox.AppendTextLine(text, Color.Green);
        richTextBox = (RichTextBox) null;
        text = (string) null;
        isOn = false;
        vm.LabelText = "부팅중";
        vm.Loading(true);
        do
        {
          Tuple<bool, JObject> tuple = await this.RequestVMState(vm, vm.VMName, (Action<string>) (stateText => vm.LabelText = "부팅중(" + stateText + ")"));
          isOn = tuple.Item1;
          JObject jsonObj = tuple.Item2;
          if (jsonObj["PowerState"] != null)
          {
            string power = jsonObj["PowerState"].ToString();
            if (!power.Equals("VM running") && !power.Equals("VM deallocated"))
              power = (string) null;
            else
              break;
          }
          if (!isOn)
            await Task.Delay(10000);
          tuple = (Tuple<bool, JObject>) null;
          jsonObj = (JObject) null;
        }
        while (!isOn);
        vm.LabelText = "부팅 중";
        await Task.Delay(90000);
        vm.Loading(false);
        vm.PowerOn(true);
        Process.Start("ms-rd:");
        param = (Dictionary<string, string>) null;
      }
    }

    private VMList CreateVMButton(string vmName)
    {
      VMList vmList = new VMList();
      vmList.Dock = DockStyle.Top;
      VMList vmButton = vmList;
      this.panelVMList.Controls.Add((Control) vmButton);
      return vmButton;
    }

    private void ClearVMButton()
    {
      foreach (Control control in VMList.All)
        this.panelVMList.Controls.Remove(control);
      VMList.Clear();
      this.OnChangeCheckedList((VMList) null);
    }

    private void OutPutTextBox_TextChanged(object sender, EventArgs e)
    {
      this.outPutTextBox.SelectionStart = this.outPutTextBox.Text.Length;
      this.outPutTextBox.ScrollToCaret();
    }

    private async Task RequestProfile()
    {
      this.loadingForm.Text = "Login";
      this.loadingForm.labelText = "Login...";
      await this.loadingForm.ShowLoading((LoadingForm.OnDialogProcess) (async () =>
      {
        this.btnLogin.Visible = false;
        this.btnLogout.Visible = true;
        this.btnRefresh.Enabled = false;
        await Task.Delay(1000);
        this.outPutTextBox.Clear();
        this.outPutTextBox.AppendTextLine("로그인 성공!!", Color.Black);
        this.btnRefresh.Enabled = true;
      }));
    }

    private async Task RequestVMList()
    {
      this.loadingForm.Text = "VM리스트 요청";
      this.loadingForm.labelText = "VM리스트 요청중...";
      await this.loadingForm.ShowLoading((LoadingForm.OnDialogProcess) (async () =>
      {
        try
        {
          Dictionary<string, string> param = new Dictionary<string, string>()
          {
            {
              "user",
              AppManager.profile.userPrincipalName
            }
          };
          string jsonText = await AppManager.RequestAPI(HttpMethod.Get, "/api/GetVMList", param);
          this.loadingForm.labelText = "VM상태 업데이트 중..";
          if (string.IsNullOrEmpty(jsonText))
          {
            this.outPutTextBox.AppendTextLine("할당 받은 VM이 없습니다...", Color.Red);
          }
          else
          {
            List<string> vmList = JsonConvert.DeserializeObject<List<string>>(jsonText);
            List<Task> tasks = new List<Task>();
            this.ClearVMButton();
            foreach (string vmName in vmList)
            {
              VMList button = this.CreateVMButton(vmName);
              tasks.Add((Task) this.VMStateUpdate(button, vmName, (Action<string>) null));
              button = (VMList) null;
            }
            await Task.WhenAll((IEnumerable<Task>) tasks);
            if (VMList.All.Count == 1)
              VMList.All[0].Value = true;
            vmList = (List<string>) null;
            tasks = (List<Task>) null;
          }
          param = (Dictionary<string, string>) null;
          jsonText = (string) null;
        }
        catch (Exception ex)
        {
          this.outPutTextBox.AppendTextLine(ex.ToString(), Color.Red);
        }
      }));
    }

    private async void SetState(MainForm.State state)
    {
      this._state = state;
      MainForm.State state1 = state;
      switch (state1)
      {
        case MainForm.State.NONE:
          this.btnLogin.Visible = true;
          this.btnLogout.Visible = false;
          this.btnRefresh.Enabled = false;
          this.outPutTextBox.Clear();
          this.outPutTextBox.AppendText("로그인이 필요합니다.");
          this.Text = "GS칼텍스 WVD-ONOFF";
          break;
        case MainForm.State.LOGIN:
          await this.RequestProfile();
          await this.RequestVMList();
          break;
        case MainForm.State.LOGOUT:
          this.btnLogin.Visible = true;
          this.btnLogout.Visible = false;
          this.btnRefresh.Enabled = false;
          this.outPutTextBox.Clear();
          this.outPutTextBox.AppendText("로그인이 필요합니다.");
          this.Text = "GS칼텍스 WVD-ONOFF - Logout";
          this.ClearVMButton();
          await AppManager.Logout();
          break;
      }
    }

    private async void Login_Click(object sender, EventArgs e)
    {
      AppManager.AppSetting appSetting = AppManager.appSetting;
      if (string.IsNullOrEmpty(appSetting.clientId) || string.IsNullOrEmpty(appSetting.tenantId) || string.IsNullOrEmpty(appSetting.baseUri))
      {
        DialogResult result = this.settingForm.ShowDialog();
        if (result == DialogResult.Cancel)
        {
          this.outPutTextBox.AppendTextLine("설정을 먼저 진행해야 합니다!!\n자세한 정보는 관리자에게 문의하세요.", Color.Red);
          appSetting = new AppManager.AppSetting();
          return;
        }
      }
      try
      {
        string accessToken = await AppManager.GetAccessTokenWithLogin();
        if (!string.IsNullOrEmpty(accessToken))
          this.SetState(MainForm.State.LOGIN);
        else
          this.SetState(MainForm.State.LOGOUT);
        accessToken = (string) null;
        appSetting = new AppManager.AppSetting();
      }
      catch (Exception ex)
      {
        this.outPutTextBox.AppendTextLine(ex.Message, Color.Red);
        appSetting = new AppManager.AppSetting();
      }
    }

    private void Logout_Click(object sender, EventArgs e)
    {
      if (MessageBox.Show(AppManager.profile.userPrincipalName + "를 로그아웃 하시겠습니까?", "Logout", MessageBoxButtons.YesNo) != DialogResult.Yes)
        return;
      this.SetState(MainForm.State.LOGOUT);
    }

    private async void VMOn_Click(object sender, EventArgs e)
    {
      Dictionary<string, string> param = new Dictionary<string, string>()
      {
        {
          "user",
          AppManager.profile.userPrincipalName
        },
        {
          "action",
          "on"
        }
      };
      RichTextBox richTextBox = this.outPutTextBox;
      string text = await AppManager.RequestAPI(HttpMethod.Post, "/api/power", param);
      richTextBox.AppendTextLine(text, Color.Black);
      richTextBox = (RichTextBox) null;
      text = (string) null;
      param = (Dictionary<string, string>) null;
    }

    private async void VMOff_Click(object sender, EventArgs e)
    {
      Dictionary<string, string> param = new Dictionary<string, string>()
      {
        {
          "user",
          AppManager.profile.userPrincipalName
        },
        {
          "action",
          "off"
        }
      };
      RichTextBox richTextBox = this.outPutTextBox;
      string text = await AppManager.RequestAPI(HttpMethod.Post, "/api/power", param);
      richTextBox.AppendTextLine(text, Color.Black);
      richTextBox = (RichTextBox) null;
      text = (string) null;
      param = (Dictionary<string, string>) null;
    }

    private async void Refresh_Click(object sender, EventArgs e)
    {
      this.btnRefresh.Enabled = false;
      await this.RequestVMList();
      List<Task> tasks = new List<Task>();
      for (int i = 0; i < VMList.All.Count; ++i)
      {
        VMList vm = VMList.All[i];
        string vmName = vm.VMName;
        tasks.Add((Task) this.VMStateUpdate(vm, vmName, (Action<string>) null));
        vm = (VMList) null;
        vmName = (string) null;
      }
      await Task.WhenAll((IEnumerable<Task>) tasks);
      this.btnRefresh.Enabled = true;
      tasks = (List<Task>) null;
    }

    private void Setting_Click(object sender, EventArgs e)
    {
      if (this.settingForm.ShowDialog() != DialogResult.Yes)
        return;
      this.SetState(MainForm.State.LOGOUT);
    }

    private void checkAll_Load(object sender, EventArgs e)
    {
      foreach (VMList vmList in VMList.All)
        vmList.Value = this.checkAll.Value;
    }

    private void OnClickStart(object sender, EventArgs e)
    {
      if (VMList.Checked.Count == 0 || MessageBox.Show("선택한 VM을 시작 하겠습니까?", "VM 시작", MessageBoxButtons.YesNo) != DialogResult.Yes)
        return;
      foreach (VMList vm in VMList.Checked)
        this.VMPowerOn(vm, true);
    }

    private void OnClickStop(object sender, EventArgs e)
    {
      if (VMList.Checked.Count == 0 || MessageBox.Show("선택한 VM을 정지 하겠습니까?", "VM 정지", MessageBoxButtons.YesNo) != DialogResult.Yes)
        return;
      foreach (VMList vm in VMList.Checked)
        this.VMPowerOn(vm, false);
    }

    private void OnClickRestart(object sender, EventArgs e)
    {
      if (VMList.Checked.Count == 0 || MessageBox.Show("선택한 VM을 재시작 하겠습니까?", "VM 재시작", MessageBoxButtons.YesNo) != DialogResult.Yes)
        return;
      foreach (VMList vm in VMList.Checked)
      {
        if (vm.IsOn)
          this.VMRestart(vm);
      }
    }

    private void OnChangeCheckedList(VMList obj) => this.btnStart.Enabled = this.btnStop.Enabled = this.btnRestart.Enabled = VMList.Checked.Count > 0;

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (MainForm));
      this.panel3 = new Panel();
      this.btnSetting = new IconButton();
      this.pictureBox1 = new PictureBox();
      this.btnLogin = new IconButton();
      this.btnLogout = new IconButton();
      this.panel2 = new Panel();
      this.outPutTextBox = new RichTextBox();
      this.flowLayoutPanel2 = new FlowLayoutPanel();
      this.checkAll = new FACheckBox();
      this.btnRefresh = new IconButton();
      this.btnStart = new IconButton();
      this.btnStop = new IconButton();
      this.btnRestart = new IconButton();
      this.panelVMList = new Panel();
      this.txtVersion = new TextBox();
      this.panel3.SuspendLayout();
      ((ISupportInitialize) this.pictureBox1).BeginInit();
      this.panel2.SuspendLayout();
      this.flowLayoutPanel2.SuspendLayout();
      this.panelVMList.SuspendLayout();
      this.SuspendLayout();
      this.panel3.BackColor = Color.White;
      this.panel3.Controls.Add((Control) this.btnSetting);
      this.panel3.Controls.Add((Control) this.pictureBox1);
      this.panel3.Controls.Add((Control) this.btnLogin);
      this.panel3.Controls.Add((Control) this.btnLogout);
      this.panel3.Dock = DockStyle.Top;
      this.panel3.Location = new Point(0, 0);
      this.panel3.Name = "panel3";
      this.panel3.Size = new Size(693, 66);
      this.panel3.TabIndex = 10;
      this.btnSetting.Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.btnSetting.BackColor = Color.Transparent;
      this.btnSetting.FlatAppearance.BorderSize = 0;
      this.btnSetting.FlatStyle = FlatStyle.Flat;
      this.btnSetting.Flip = FlipOrientation.Normal;
      this.btnSetting.ForeColor = Color.White;
      this.btnSetting.IconChar = IconChar.UserCog;
      this.btnSetting.IconColor = Color.White;
      this.btnSetting.IconSize = 25;
      this.btnSetting.ImageAlign = ContentAlignment.MiddleLeft;
      this.btnSetting.Location = new Point(463, 33);
      this.btnSetting.Name = "btnSetting";
      this.btnSetting.Rotation = 0.0;
      this.btnSetting.Size = new Size(106, 33);
      this.btnSetting.TabIndex = 10;
      this.btnSetting.Text = "  구독 설정";
      this.btnSetting.TextAlign = ContentAlignment.MiddleLeft;
      this.btnSetting.TextImageRelation = TextImageRelation.ImageBeforeText;
      this.btnSetting.UseVisualStyleBackColor = false;
      this.btnSetting.Visible = false;
      this.btnSetting.Click += new EventHandler(this.Setting_Click);
      this.pictureBox1.Dock = DockStyle.Left;
      this.pictureBox1.Image = (Image) Resource.IMG_COMP_LOGIN_LOGO_A_techdataglobal;
      this.pictureBox1.Location = new Point(0, 0);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new Size(129, 66);
      this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
      this.pictureBox1.TabIndex = 5;
      this.pictureBox1.TabStop = false;
      this.btnLogin.Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.btnLogin.BackColor = Color.Transparent;
      this.btnLogin.FlatAppearance.BorderSize = 0;
      this.btnLogin.FlatStyle = FlatStyle.Flat;
      this.btnLogin.Flip = FlipOrientation.Normal;
      this.btnLogin.ForeColor = Color.Black;
      this.btnLogin.IconChar = IconChar.SignInAlt;
      this.btnLogin.IconColor = Color.Black;
      this.btnLogin.IconSize = 25;
      this.btnLogin.ImageAlign = ContentAlignment.MiddleLeft;
      this.btnLogin.Location = new Point(575, 33);
      this.btnLogin.Name = "btnLogin";
      this.btnLogin.Rotation = 0.0;
      this.btnLogin.Size = new Size(106, 33);
      this.btnLogin.TabIndex = 9;
      this.btnLogin.Text = "  로그인";
      this.btnLogin.TextAlign = ContentAlignment.MiddleLeft;
      this.btnLogin.TextImageRelation = TextImageRelation.ImageBeforeText;
      this.btnLogin.UseVisualStyleBackColor = false;
      this.btnLogin.Click += new EventHandler(this.Login_Click);
      this.btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.btnLogout.BackColor = Color.Transparent;
      this.btnLogout.FlatAppearance.BorderSize = 0;
      this.btnLogout.FlatStyle = FlatStyle.Flat;
      this.btnLogout.Flip = FlipOrientation.Normal;
      this.btnLogout.ForeColor = Color.Black;
      this.btnLogout.IconChar = IconChar.SignOutAlt;
      this.btnLogout.IconColor = Color.Black;
      this.btnLogout.IconSize = 25;
      this.btnLogout.ImageAlign = ContentAlignment.MiddleLeft;
      this.btnLogout.Location = new Point(575, 33);
      this.btnLogout.Name = "btnLogout";
      this.btnLogout.Rotation = 0.0;
      this.btnLogout.Size = new Size(106, 33);
      this.btnLogout.TabIndex = 11;
      this.btnLogout.Text = "  로그 아웃";
      this.btnLogout.TextAlign = ContentAlignment.MiddleLeft;
      this.btnLogout.TextImageRelation = TextImageRelation.ImageBeforeText;
      this.btnLogout.UseVisualStyleBackColor = false;
      this.btnLogout.Click += new EventHandler(this.Logout_Click);
      this.panel2.Controls.Add((Control) this.outPutTextBox);
      this.panel2.Dock = DockStyle.Bottom;
      this.panel2.Location = new Point(0, 353);
      this.panel2.Name = "panel2";
      this.panel2.Size = new Size(693, 54);
      this.panel2.TabIndex = 14;
      this.outPutTextBox.BackColor = Color.FromArgb(240, 240, 240);
      this.outPutTextBox.Dock = DockStyle.Fill;
      this.outPutTextBox.ForeColor = Color.Black;
      this.outPutTextBox.ImeMode = ImeMode.NoControl;
      this.outPutTextBox.Location = new Point(0, 0);
      this.outPutTextBox.Name = "outPutTextBox";
      this.outPutTextBox.ReadOnly = true;
      this.outPutTextBox.ScrollBars = RichTextBoxScrollBars.Vertical;
      this.outPutTextBox.Size = new Size(693, 54);
      this.outPutTextBox.TabIndex = 1;
      this.outPutTextBox.Text = "";
      this.flowLayoutPanel2.BackColor = Color.White;
      this.flowLayoutPanel2.Controls.Add((Control) this.checkAll);
      this.flowLayoutPanel2.Controls.Add((Control) this.btnRefresh);
      this.flowLayoutPanel2.Controls.Add((Control) this.btnStart);
      this.flowLayoutPanel2.Controls.Add((Control) this.btnStop);
      this.flowLayoutPanel2.Controls.Add((Control) this.btnRestart);
      this.flowLayoutPanel2.Dock = DockStyle.Top;
      this.flowLayoutPanel2.Location = new Point(0, 66);
      this.flowLayoutPanel2.Name = "flowLayoutPanel2";
      this.flowLayoutPanel2.Size = new Size(693, 33);
      this.flowLayoutPanel2.TabIndex = 15;
      this.checkAll.BackColor = Color.Transparent;
      this.checkAll.ForeColor = Color.Black;
      this.checkAll.Location = new Point(3, 3);
      this.checkAll.Name = "checkAll";
      this.checkAll.Size = new Size(42, 30);
      this.checkAll.TabIndex = 13;
      this.checkAll.Value = false;
      this.checkAll.Load += new EventHandler(this.checkAll_Load);
      this.checkAll.Click += new EventHandler(this.checkAll_Load);
      this.checkAll.DoubleClick += new EventHandler(this.checkAll_Load);
      this.btnRefresh.AutoSize = true;
      this.btnRefresh.AutoSizeMode = AutoSizeMode.GrowAndShrink;
      this.btnRefresh.BackColor = Color.Transparent;
      this.btnRefresh.FlatAppearance.BorderSize = 0;
      this.btnRefresh.FlatStyle = FlatStyle.Flat;
      this.btnRefresh.Flip = FlipOrientation.Normal;
      this.btnRefresh.Font = new Font("굴림", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 129);
      this.btnRefresh.ForeColor = Color.Black;
      this.btnRefresh.IconChar = IconChar.SyncAlt;
      this.btnRefresh.IconColor = Color.Black;
      this.btnRefresh.IconSize = 20;
      this.btnRefresh.ImageAlign = ContentAlignment.MiddleLeft;
      this.btnRefresh.Location = new Point(51, 3);
      this.btnRefresh.Name = "btnRefresh";
      this.btnRefresh.Rotation = 0.0;
      this.btnRefresh.Size = new Size(101, 26);
      this.btnRefresh.TabIndex = 12;
      this.btnRefresh.Text = "  새로 고침";
      this.btnRefresh.TextAlign = ContentAlignment.MiddleLeft;
      this.btnRefresh.TextImageRelation = TextImageRelation.ImageBeforeText;
      this.btnRefresh.UseVisualStyleBackColor = false;
      this.btnRefresh.Visible = false;
      this.btnRefresh.Click += new EventHandler(this.Refresh_Click);
      this.btnStart.AutoSize = true;
      this.btnStart.AutoSizeMode = AutoSizeMode.GrowAndShrink;
      this.btnStart.BackColor = Color.Transparent;
      this.btnStart.FlatAppearance.BorderSize = 0;
      this.btnStart.FlatStyle = FlatStyle.Flat;
      this.btnStart.Flip = FlipOrientation.Normal;
      this.btnStart.Font = new Font("굴림", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 129);
      this.btnStart.ForeColor = Color.Black;
      this.btnStart.IconChar = IconChar.Play;
      this.btnStart.IconColor = Color.Black;
      this.btnStart.IconSize = 20;
      this.btnStart.ImageAlign = ContentAlignment.MiddleLeft;
      this.btnStart.Location = new Point(158, 3);
      this.btnStart.Name = "btnStart";
      this.btnStart.Rotation = 0.0;
      this.btnStart.Size = new Size(71, 26);
      this.btnStart.TabIndex = 9;
      this.btnStart.Text = "  시작";
      this.btnStart.TextAlign = ContentAlignment.MiddleLeft;
      this.btnStart.TextImageRelation = TextImageRelation.ImageBeforeText;
      this.btnStart.UseVisualStyleBackColor = false;
      this.btnStart.Click += new EventHandler(this.OnClickStart);
      this.btnStop.AutoSize = true;
      this.btnStop.AutoSizeMode = AutoSizeMode.GrowAndShrink;
      this.btnStop.BackColor = Color.Transparent;
      this.btnStop.FlatAppearance.BorderSize = 0;
      this.btnStop.FlatStyle = FlatStyle.Flat;
      this.btnStop.Flip = FlipOrientation.Normal;
      this.btnStop.Font = new Font("굴림", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 129);
      this.btnStop.ForeColor = Color.Black;
      this.btnStop.IconChar = IconChar.Stop;
      this.btnStop.IconColor = Color.Black;
      this.btnStop.IconSize = 20;
      this.btnStop.ImageAlign = ContentAlignment.MiddleLeft;
      this.btnStop.Location = new Point(235, 3);
      this.btnStop.Name = "btnStop";
      this.btnStop.Rotation = 0.0;
      this.btnStop.Size = new Size(71, 26);
      this.btnStop.TabIndex = 10;
      this.btnStop.Text = "  중지";
      this.btnStop.TextAlign = ContentAlignment.MiddleLeft;
      this.btnStop.TextImageRelation = TextImageRelation.ImageBeforeText;
      this.btnStop.UseVisualStyleBackColor = false;
      this.btnStop.Click += new EventHandler(this.OnClickStop);
      this.btnRestart.AutoSize = true;
      this.btnRestart.AutoSizeMode = AutoSizeMode.GrowAndShrink;
      this.btnRestart.BackColor = Color.Transparent;
      this.btnRestart.FlatAppearance.BorderSize = 0;
      this.btnRestart.FlatStyle = FlatStyle.Flat;
      this.btnRestart.Flip = FlipOrientation.Normal;
      this.btnRestart.Font = new Font("굴림", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 129);
      this.btnRestart.ForeColor = Color.Black;
      this.btnRestart.IconChar = IconChar.Retweet;
      this.btnRestart.IconColor = Color.Black;
      this.btnRestart.IconSize = 20;
      this.btnRestart.ImageAlign = ContentAlignment.MiddleLeft;
      this.btnRestart.Location = new Point(312, 3);
      this.btnRestart.Name = "btnRestart";
      this.btnRestart.Rotation = 0.0;
      this.btnRestart.Size = new Size(84, 26);
      this.btnRestart.TabIndex = 11;
      this.btnRestart.Text = "  재시작";
      this.btnRestart.TextAlign = ContentAlignment.MiddleLeft;
      this.btnRestart.TextImageRelation = TextImageRelation.ImageBeforeText;
      this.btnRestart.UseVisualStyleBackColor = false;
      this.btnRestart.Click += new EventHandler(this.OnClickRestart);
      this.panelVMList.AutoScroll = true;
      this.panelVMList.BackColor = Color.White;
      this.panelVMList.Controls.Add((Control) this.txtVersion);
      this.panelVMList.Dock = DockStyle.Fill;
      this.panelVMList.Location = new Point(0, 99);
      this.panelVMList.Name = "panelVMList";
      this.panelVMList.Size = new Size(693, 254);
      this.panelVMList.TabIndex = 17;
      this.txtVersion.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
      this.txtVersion.BackColor = Color.White;
      this.txtVersion.BorderStyle = BorderStyle.None;
      this.txtVersion.Location = new Point(590, 234);
      this.txtVersion.Name = "txtVersion";
      this.txtVersion.ReadOnly = true;
      this.txtVersion.Size = new Size(100, 14);
      this.txtVersion.TabIndex = 13;
      this.txtVersion.Text = "v1.4b";
      this.txtVersion.TextAlign = HorizontalAlignment.Right;
      this.AutoScaleDimensions = new SizeF(7f, 12f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(693, 407);
      this.Controls.Add((Control) this.panelVMList);
      this.Controls.Add((Control) this.flowLayoutPanel2);
      this.Controls.Add((Control) this.panel2);
      this.Controls.Add((Control) this.panel3);
      this.Icon = (System.Drawing.Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (MainForm);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "GS칼텍스 WVD-ONOFF";
      this.panel3.ResumeLayout(false);
      ((ISupportInitialize) this.pictureBox1).EndInit();
      this.panel2.ResumeLayout(false);
      this.flowLayoutPanel2.ResumeLayout(false);
      this.flowLayoutPanel2.PerformLayout();
      this.panelVMList.ResumeLayout(false);
      this.panelVMList.PerformLayout();
      this.ResumeLayout(false);
    }

    private enum State
    {
      NONE,
      LOGIN,
      LOGOUT,
    }
  }
}
